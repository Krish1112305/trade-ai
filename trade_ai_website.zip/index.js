import React from "react";
import ReactDOM from "react-dom";
import TradeAIDashboard from "./TradeAIDashboard";

ReactDOM.render(<TradeAIDashboard />, document.getElementById("root"));
